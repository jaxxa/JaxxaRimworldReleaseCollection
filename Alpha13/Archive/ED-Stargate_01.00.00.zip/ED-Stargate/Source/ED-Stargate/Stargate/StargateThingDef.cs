﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Enhanced_Development.Stargate
{
    public class StargateThingDef : Verse.ThingDef
    {
        public string FileLocationPrimary;
        public string FileLocationSecondary;
    }
}
