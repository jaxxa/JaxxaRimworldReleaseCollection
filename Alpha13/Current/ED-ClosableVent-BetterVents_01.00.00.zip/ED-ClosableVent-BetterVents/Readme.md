Changes:

Thingclass

add flickable comp