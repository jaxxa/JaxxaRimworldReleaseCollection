# ED-ReverseCycleCooler
This module changes the cooler to have a rotate option; this allows you to switch it between cooling a room and using its output to warm the same room.

#Change Log

01.00.00
*Initial Release

01.00.01
* Adding Dependencies.xml
* Removing unneeded logging.