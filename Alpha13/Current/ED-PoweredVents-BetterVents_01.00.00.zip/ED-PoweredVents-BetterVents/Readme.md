Changes:

Thingclass

AddedComps
CompProperties_Power
CompProperties_Breakdownable
CompProperties_Flickable