# ED-Plants24H
The module changes the plants to grow 24 Hours a day. In the base game plants will rest at night time and stop growing, regardless of the light levels. This removed that restriction so plants will keep growing, if all the other conditions such as light are still met, allowing your sunlamps to effectively increase the growing speed.

#Change Log

01.00.00
*Initial Release

02.00.00
* Compleate Rewrite of the mod. Now requires CCL due to use of Detours.
  * Should no longer require Compatability patches to work with modded plants. 
  * Delete the old version of the mod and any existing Compatability patches as these will now caulse Errors.