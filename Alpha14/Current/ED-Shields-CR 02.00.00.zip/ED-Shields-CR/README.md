# ED-Shields-CR

	Requires: ED-Shields, Community Core Library, CombatRealism
	
Modifies the Shields from ED-Shields to intercept the projectiles fired by weapons from Combat Realism.

#Change Log

01.00.00
*Initial Release

