# ED-SubspaceTransponder

#Change Log

01.00.00
*Initial Release

01.00.01
*Fixing issue with charge / discharge.

