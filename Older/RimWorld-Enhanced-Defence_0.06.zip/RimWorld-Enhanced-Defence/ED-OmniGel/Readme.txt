Install:
To install place the directory called "OmniGel" (that contains the folders About,Defs,Textures) into your Mods folder.
Then activate from the mods option on the main menu screen.

About:
This mod is for Alpha 6.

This mod allows you to have a renewable source of Metal and Stone.
You start by planting and harvesting the OmniGel plant.
You then need to research and build a MK1Replicator.
This is a workbench that allows you to transform the OmniGel that you harvest into slag or rock.
You then use this in the standard rock cutting or slag refining benches are in rimworld to get usable materials.

MK1:
10 OmniGel -> 1 ChunkSlag
10 OmniGel -> 1 ChunkRock

MK2
75 OmniGel -> 50 Metal
75 OmniGel -> 50 StoneBlocks
75 OmniGel -> 50 Silver

MK3
75 OmniGel -> 10 Uranium
75 OmniGel -> 10 Shells
75 OmniGel -> 10 Missiles
75 OmniGel -> 5 Medicine

Legal:
Feel free to edit this or use it in your own mod as long as you reference me.

ChangeLog
0.02
	-Initial Public Release
0.03
	-Added Mk2 and MK3 with additional recipes
0.04
	-Updated to Alpha 6

-Jaxxa