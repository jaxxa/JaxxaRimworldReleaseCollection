# ED-MoreVanillaTurrets
This is a mod that adds more turret variations with the attempt to keep their vanilla art style.
Currently this is almost exactly the same as the A12 version by Marnador.

#Change Log

01.00.00
*Initial Release

01.00.01
*Added ability to Flick on / Off Turrets