﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;
using RimWorld;
using UnityEngine;

namespace ED_Plants24H.Plants24H.Detours
{
    internal class _Plant : RimWorld.Plant
    {

        private Boolean _Resting
        {
            get
            {
                return false;
            }
        }

    }
}
