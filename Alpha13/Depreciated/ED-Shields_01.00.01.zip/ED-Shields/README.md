# ED-Shields
A mod for the Game Rimworld


This mod allows you to place shield generators. They are expensive and power hungry but can really strengthen your defences. The standard shields will stop projectiles that try to enter it, but allow weapons to be fired out.

#Change Log

01.00.00
*Initial Release

01.00.01
*Fix for Shields blocking not just from the edge.