Cannon Ammo and Turrets

###About:
This is an edit of PunisheR007's mod "Cannons and Turrets" http://ludeon.com/forums/index.php?topic=3878.0 combined with my "Turret Ammo" mod http://ludeon.com/forums/index.php?topic=5183.0

The main change that I have made is that all of the heavier cannons will require a constant supply of ammunition to keep firing.

The idea behind this mod is to keep the awesome cannons and turrets that are In the mod, but require a decision to employ them or not because they will be using resources, so sometimes you will be better dealing with smaller attacks without the cannons.

Because of this I have rebalanced the costs involved with deploying the cannons (removing the shell/missile requirement to build them and reducing the power requirement).

Almost all of the stats are identical to the base mod by PunisheR007, so look through the title page of that mod for information on damage / firerate ect.

I have changed the display string on the smaller turrets to reduce the number of lines that it takes up, but have not made any game play changes to those (they don't need ammo).

### How to use:

The ammunition is provided by building a Hopper next to the Turret and filling it with the Ammunition resource that the turret requires, (usually Shells or Missiles).
If insufficient Ammunition is found to fire the Turret will powerdown and not powerup until the ammunition is provided.
Clicking on the Turret can provide information about the amount and type of resources that it requires.

###ChangeLog

0.01
	-Initial public release
	-Changed Cannons to use Ammo
		-Structure_Kaytusha_MRL
		-Structure_Howitzer_Cannon
		-Structure_Flak_Cannon
		-Structure_Artillery_Cannon
	-Removed Shells / Missile Requirment to build Cannon
	-Reduced power usage
	-Customised Hopper to Take Ammo
	-Changed the Inspection String of all Turrets to reduce the number of lines that it takes up
		-Stops getting the warning message for over 5 lines and not being able to see the last line when a turret had power, a cooldown and a min range.
	
##Legal:
Based on PunisheR007's mod "Cannons and Turrets" http://ludeon.com/forums/index.php?topic=3878.0
This work is licensed under http://creativecommons.org/licenses/by/4.0/

###Base mod Changelog:
v1.0:   - Artillery cannon turret.

v1.1:   - Fixed cannon turret overiding improvised turret.

v1.2:   - Raised projectile speed by 1/3.

v1.3:   - New cannon texture.

v1.4:   - Fixed the turret textures to look more centred on the structure
        and will now take 2x2 squares instead of 1x1.
        - Added a few touches to the textures. (muzzle break)
        - Raised the projectile speed from 35 to 55.
        - Raised explosion radius from 1.5 to 2.5.
        - Reduced reload time by 1 sec

v1.5:   - Research now needed to build the artillery cannon
        1. Self propelled guns, leading to high explosives (cost 3500)
        2. High explosives leading to the cannon (cost 2500)
        - 10 Shells are also needed with the 650 metal to build 1 cannon
        - Raised the reload time to 5.5 secs
        - Raised the projectile speed from 55 to 85

v1.51:  - Bit of code cleanup
        - Changed the range and placing display radius from 55 to 56,
           56 is the maximum placing display radius possible atm.
        - Changed the explosion radius of the shells from 2.5 to 3.0.
           and accuracy from 6 to 10.

v1.6:   - Tweaked warmup, cooldown and reload times to be more closer to stats.
        - Tripled the firing range and tweaked the minimum range alot more closer to the turret.

v1.7:   - Added 2 new sounds *Pre-impact* and *explosion* sounds
        - Changed the projectile texture a bit, so you can see it better.

v2.0    - Mod now called Cannons
        - Changed cannon names to artillery cannon and howitzer cannon
        - Artillery cannon fires over walls/mountains/rocks, and
        the Howitzer cannon is the original cannon and doesn't have the pre-impact sound.
        - Both cannons are from the same research pre-requisites.

v2.1    - Tweaked the stats of both cannons.
        - New howitzer cannon texture.
        - damage now doesn't instantly disintergrate enemys,
        thats how i wanted it initially :).

v2.2    - added new artillery firing sound, howitzer got the artillery sound.
        - tweaked the volumes of all sounds.

v2.3    - Added new research, ballistics, howitzer and artillery armour plating.
        - Changed the research tree for artillery and howitzer cannons.
        - changed the work to build of the howitzer from 1000 to 850.
        - Changed the cost of the artillery from 650 metal to 850 and from 10 shells to 20.

v3.0    - Mod renamed to Cannons and Turrets
        - Merged Kilroy's killer turret pack
        - Grenade turret has been removed (for now) will put back if everyone wants it.
        - Reworked research tree of turret pack.
        - All turrets have new armour plating research, 
          when each turret becomes available through research.
        - Added reinforced metal walls and fire proof metal walls research.
        - Added colonist fitness training research.

v3.1   - Tweaked the artillery cannon's accuracy.
         - Added colonist endurance, strength training and diet program research.
         - all slaves from slave traders will benefit from the colonist training and diet program.
         - 50% more walk speed for all colonist who benefit from training.
         - Remember only the 3 orig starting colonist and slaves from slave traders,
           will benefit from the 50% more walk speed, training, and the diet program.

v3.2     - Artillery accuracy decreased, explosion radius and damage increased.
         - Howitzer accuracy, explosion radius and damage increased.
         - Colonist training removed and moved to it's own mod. (Enhanced Colonists)
         - Metal costs reduced.
         - Shell costs increased.
         - Started working on a new flak style cannon.

v3.3     - Added new 20mm Flak cannon.

v3.4     - Added new Kaytusha MRL (Multiple rocket launcher) With firing sound.
         - Removed preimpact sound for flak cannon, to make artillery cannon unique.

v3.5     - Added new howitzer sound, artillery got the old howitzer sound 
           and the flak got the artillery sound.
           Sounds alot better, and more relative to the size of the cannons.
         - Accuracy, damage and firing speed re-balancing.
         - Kaytusha now fires incendiary rockets and fires 2 extra shots. (8 missles)
           
v3.6     - Further Re-balancing of damage, explosion radius, firerate and range.